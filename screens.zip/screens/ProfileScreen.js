import { View, Text } from 'react-native'
import React from 'react'

const ProfileScreen = () => {
  return (
    <View>
      <Text>Profile Screen</Text>
    </View>
  )
}

export default ProfileScreen