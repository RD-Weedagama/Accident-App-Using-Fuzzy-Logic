import { View, Text } from 'react-native'
import React from 'react'

const History = () => {
  return (
    <View>
      <Text>History</Text>
    </View>
  )
}

export default History