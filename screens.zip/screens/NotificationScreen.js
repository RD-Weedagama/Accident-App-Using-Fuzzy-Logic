import { View, Text } from 'react-native'
import React from 'react'

const NotificationScreen = () => {
  return (
    <View>
      <Text>Notification Screen</Text>
    </View>
  )
}

export default NotificationScreen