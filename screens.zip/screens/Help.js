import { View, Text } from 'react-native'
import React from 'react'

const Help = () => {
  return (
    <View>
      <Text>Help</Text>
    </View>
  )
}

export default Help