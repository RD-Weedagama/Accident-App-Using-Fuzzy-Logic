import {useNavigation} from '@react-navigation/core';
import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View, Image} from 'react-native';
import {auth} from '../firebase';
import Ionic from 'react-native-vector-icons/Ionicons';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import HomeScreen from './HomeScreen';
import NotificationScreen from './NotificationScreen';
import DrivingScreen from './DrivingScreen';
import ProfileScreen from './ProfileScreen';
import EmergencyContactScreen from './EmergencyContactScreen';

const MainScreen = () => {
  const navigation = useNavigation();
  const Tab = createBottomTabNavigator();

  return (
    <NavigationContainer independent={true}>
      <Tab.Navigator
        screenOptions={({route}) => ({
          tabBarIcon: ({focused, size, color}) => {
            let iconName;
            if (route.name === 'Home') {
              iconName = focused ? 'ios-home' : 'ios-home-outline';
              size = focused ? size + 18 : size + 5;
            } 
            else if (route.name === 'Drive') {
              iconName = focused ? 'car-sport-sharp' : 'car-sport-outline';
              size = focused ? size + 18 : size + 5;
            }
            if (route.name === 'Notification') {
              iconName = focused ? 'notifications' : 'notifications-outline';
              size = focused ? size + 18 : size + 5;
            }
            if (route.name === 'Profile') {
              iconName = focused ? 'md-person' : 'person-outline';
              size = focused ? size + 18 : size + 5;
            }
            return <Ionic name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          activeTintColor: '#DC3545',
          inactiveTintColor: 'black',
          showLabel: false,
          style: {backgroundColor: '#ffc125', Height: 60},
        }}>
        <Tab.Screen name="Home" options={{ headerShown: false }} component={HomeScreen} />
        <Tab.Screen name="Drive" options={{ headerShown: false }} component={DrivingScreen} />
        <Tab.Screen name="Notification" component={NotificationScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default MainScreen;
