import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  Image,
} from 'react-native';
import React from 'react';
import { DeviceMotion } from 'react-native';


const DrivingScreen = () => {
  return (
   <View>
    <Text>Helloo oo</Text>
   </View>
  );
};

export default DrivingScreen;

